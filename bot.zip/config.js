module.exports = {
    token: process.env.TOKEN || 'your-token-here',
    clientId: process.env.CLIENT_ID || 'your-client-id-here',
    guildId: process.env.GUILD_ID || 'your-guild-id-here'
};
